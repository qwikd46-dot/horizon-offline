#version 330 core
#include "/lib/vanilla.vsh"
