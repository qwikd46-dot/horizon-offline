#version 330 core
#define USE_TEXTURE
#define USE_LIGHTMAP
#define USE_ENTITY_COLOR
#define USE_FOG
#include "/lib/vanilla.fsh"
