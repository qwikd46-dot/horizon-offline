#version 330 core
#define USE_TEXTURE
#define USE_LIGHTMAP
#define USE_ENTITY_COLOR
#define USE_FOG
#define USE_ALPHA_TEST
#include "/lib/vanilla.fsh"
