#version 330 core

#include "/lib/water_common.glsl"

uniform sampler2D gtexture;
uniform sampler2D lightmap;

uniform mat4 gbufferModelView;
uniform vec3 fogColor;
uniform float fogDensity;
uniform float fogStart;
uniform float fogEnd;
uniform int fogMode;
uniform int fogShape;
uniform float frameTimeCounter;

in vec2 vTexCoord;
in vec2 vLightCoord;
in vec4 vColor;
in vec3 vWorldPos;
in vec3 vViewPos;
in vec3 vBaseNormalWorld;
in float vWaveFade;
flat in int vIsWater;
flat in int vIsTopSurface;

layout(location = 0) out vec4 sceneColor;
layout(location = 1) out vec4 waterSurfaceData;
/* RENDERTARGETS: 0,2 */

float vrwFogVisibility(vec3 viewPosition) {
    float distanceToCamera = fogShape == 1
        ? max(length(viewPosition.xz), abs(viewPosition.y))
        : length(viewPosition);

    if (fogMode == 2048) {
        return clamp(exp(-fogDensity * distanceToCamera), 0.0, 1.0);
    }
    if (fogMode == 2049) {
        float densityDistance = fogDensity * distanceToCamera;
        return clamp(exp(-(densityDistance * densityDistance)), 0.0, 1.0);
    }
    return clamp((fogEnd - distanceToCamera) / max(fogEnd - fogStart, 0.0001),
                 0.0, 1.0);
}

vec2 vrwSignNotZero(vec2 value) {
    return vec2(value.x >= 0.0 ? 1.0 : -1.0,
                value.y >= 0.0 ? 1.0 : -1.0);
}

vec2 vrwEncodeOctahedron(vec3 normal) {
    normal /= max(abs(normal.x) + abs(normal.y) + abs(normal.z), 0.000001);
    vec2 encoded = normal.xy;
    if (normal.z < 0.0) {
        encoded = (1.0 - abs(encoded.yx)) * vrwSignNotZero(encoded.xy);
    }
    return encoded * 0.5 + 0.5;
}

void main() {
    vec4 vanilla = texture(gtexture, vTexCoord)
                 * texture(lightmap, vLightCoord)
                 * vColor;

    // Iris sends all translucent terrain through gbuffers_water, including
    // glass, slime blocks and resource-pack leaf extensions. Keep those blocks
    // on Minecraft's ordinary texture/lightmap/fog path and write a zero marker
    // so the later composite pass cannot mistake them for water.
    if (vIsWater == 0) {
        vanilla.rgb = mix(fogColor, vanilla.rgb, vrwFogVisibility(vViewPos));
        sceneColor = vanilla;
        waterSurfaceData = vec4(0.0);
        return;
    }

    vec3 baseNormalWorld = normalize(vBaseNormalWorld);
    vec3 surfaceNormalWorld = baseNormalWorld;
    if (vIsTopSurface == 1) {
        vec3 waveNormal = vrwGerstnerNormal(vWorldPos.xz, frameTimeCounter);
        surfaceNormalWorld = normalize(mix(vec3(0.0, 1.0, 0.0),
                                           waveNormal, vWaveFade));
    }

    vec3 surfaceNormalView = normalize(mat3(gbufferModelView) * surfaceNormalWorld);
    vec3 viewDirection = normalize(-vViewPos);
    if (dot(surfaceNormalView, viewDirection) < 0.0) {
        surfaceNormalView = -surfaceNormalView;
    }

    // Different architecture: the translucent pass performs no water colour,
    // fog, reflection or refraction at all. It only records a high-precision
    // surface normal and linear depth. The later composite pass replaces the
    // marked pixel exactly once, after particles and translucent geometry.
    float linearDepth = max(-vViewPos.z, 0.001);
    float signedDepth = vIsTopSurface == 1 ? linearDepth : -linearDepth;

    sceneColor = vec4(0.0); // Alpha zero leaves the completed scene untouched.
    waterSurfaceData = vec4(vrwEncodeOctahedron(surfaceNormalView),
                            signedDepth, 1.0);
}
