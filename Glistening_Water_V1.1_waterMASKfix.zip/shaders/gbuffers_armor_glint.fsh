#version 330 core
#define USE_TEXTURE
#include "/lib/vanilla.fsh"
