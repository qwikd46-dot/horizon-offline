#version 330 core

#include "/lib/settings.glsl"

#define RGBA16F 0
const int colortex2Format = RGBA16F;
const bool colortex2Clear = true;
const vec4 colortex2ClearColor = vec4(0.0, 0.0, 0.0, 0.0);

uniform sampler2D colortex0;
uniform sampler2D colortex1;
uniform sampler2D colortex2;
uniform sampler2D depthtex1;

uniform mat4 gbufferModelView;
uniform mat4 gbufferProjection;
uniform mat4 gbufferProjectionInverse;
uniform vec3 sunPosition;
uniform vec3 upPosition;
uniform vec3 skyColor;
uniform vec3 fogColor;
uniform int worldTime;
uniform int isEyeInWater;
uniform float rainStrength;
uniform float frameTimeCounter;
uniform float viewWidth;
uniform float viewHeight;

in vec2 vScreenCoord;
out vec4 fragColor;
/* RENDERTARGETS: 0 */

const int VRW_REFLECTION_STEPS = 30;
const float VRW_TAU = 6.28318530717958647692;

float vrwLuminance(vec3 color) {
    return dot(color, vec3(0.2126, 0.7152, 0.0722));
}

vec2 vrwSignNotZero(vec2 value) {
    return vec2(value.x >= 0.0 ? 1.0 : -1.0,
                value.y >= 0.0 ? 1.0 : -1.0);
}

vec3 vrwDecodeOctahedron(vec2 encoded) {
    vec2 octahedron = encoded * 2.0 - 1.0;
    vec3 normal = vec3(octahedron,
                       1.0 - abs(octahedron.x) - abs(octahedron.y));
    if (normal.z < 0.0) {
        normal.xy = (1.0 - abs(normal.yx)) * vrwSignNotZero(normal.xy);
    }
    return normalize(normal);
}

vec3 vrwScreenToView(vec2 uv, float depth) {
    vec4 clip = vec4(uv * 2.0 - 1.0, depth * 2.0 - 1.0, 1.0);
    vec4 view = gbufferProjectionInverse * clip;
    float safeW = abs(view.w) < 0.000001
        ? (view.w < 0.0 ? -0.000001 : 0.000001)
        : view.w;
    return view.xyz / safeW;
}

vec3 vrwViewRayPosition(vec2 uv, float linearDepth) {
    vec3 farView = vrwScreenToView(uv, 1.0);
    float scale = linearDepth / max(-farView.z, 0.000001);
    return farView * scale;
}

vec2 vrwViewToScreen(vec3 viewPosition) {
    vec4 clip = gbufferProjection * vec4(viewPosition, 1.0);
    float safeW = abs(clip.w) < 0.000001
        ? (clip.w < 0.0 ? -0.000001 : 0.000001)
        : clip.w;
    return clip.xy / safeW * 0.5 + 0.5;
}

float vrwEdgeConfidence(vec2 uv) {
    vec2 lowerEdge = smoothstep(vec2(0.0), vec2(0.075), uv);
    vec2 upperEdge = smoothstep(vec2(0.0), vec2(0.075), vec2(1.0) - uv);
    vec2 confidence = lowerEdge * upperEdge;
    return confidence.x * confidence.y;
}

vec2 vrwUnderwaterRefractionUV(vec2 uv) {
#ifdef WAVES_ENABLED
    // A smooth submerged lens for pixels that do not contain a rendered water
    // surface. This lets refraction remain visible below the surface without
    // re-lighting the scene or applying the surface optical model twice.
    float aspect = viewWidth / max(viewHeight, 1.0);
    vec2 position = vec2(uv.x * aspect, uv.y);
    float time = frameTimeCounter * WAVE_SPEED;

    float phaseA = VRW_TAU * dot(position, vec2(3.71,  1.17)) + time * 1.30;
    float phaseB = VRW_TAU * dot(position, vec2(-1.83, 4.93)) - time * 0.93;
    float phaseC = VRW_TAU * dot(position, vec2(2.27, -3.19)) + time * 0.67;

    vec2 distortion = vec2(
        sin(phaseA) * 0.58 + sin(phaseB) * 0.29 + sin(phaseC) * 0.13,
        cos(phaseA) * 0.25 - cos(phaseB) * 0.52 + cos(phaseC) * 0.23
    );
    float waveScale = clamp(WAVE_STRENGTH / 0.220, 0.0, 1.50);
    float refractionScale = 0.0024 * REFRACTION_STRENGTH * waveScale;
    vec2 refractedUV = uv + distortion * refractionScale
                            * vrwEdgeConfidence(uv);
    return clamp(refractedUV, vec2(0.001), vec2(0.999));
#else
    return uv;
#endif
}

bool vrwTraceReflection(vec3 startView, vec3 rayDirection,
                        out vec2 hitUV, out float confidence) {
    vec3 rayPosition = startView + rayDirection * 0.14;

    for (int i = 0; i < VRW_REFLECTION_STEPS; ++i) {
        float progress = (float(i) + 1.0) / float(VRW_REFLECTION_STEPS);
        float stepLength = mix(0.14, 1.35, progress * progress);
        rayPosition += rayDirection * stepLength;

        if (rayPosition.z > -0.04) break;
        vec2 uv = vrwViewToScreen(rayPosition);
        if (uv.x <= 0.001 || uv.x >= 0.999 ||
            uv.y <= 0.001 || uv.y >= 0.999) break;

        float sceneDepth = texture(depthtex1, uv).r;
        if (sceneDepth >= 0.99999) continue;

        vec3 sceneView = vrwScreenToView(uv, sceneDepth);
        float rayDepth = -rayPosition.z;
        float sceneViewDepth = -sceneView.z;
        float crossing = rayDepth - sceneViewDepth;
        float allowedThickness = 0.22 + stepLength * 1.10
                               + rayDepth * 0.012;

        if (crossing > 0.0 && crossing < allowedThickness) {
            hitUV = uv;
            confidence = vrwEdgeConfidence(uv) * (1.0 - progress * 0.22);
            return true;
        }
    }

    hitUV = vec2(0.5);
    confidence = 0.0;
    return false;
}

vec3 vrwSunlessSkySample(vec2 skyUV, vec3 reflectionDirection) {
    vec3 directSky = texture(colortex1, skyUV).rgb;
    vec3 sunDirection = normalize(sunPosition);
    float sunAlignment = dot(normalize(reflectionDirection), sunDirection);
    float sunDiscMask = smoothstep(0.9980, 0.99975, sunAlignment);
    if (sunDiscMask <= 0.0001) return directSky;

    // The completed vanilla scene contains Minecraft's hard sun sprite. A real
    // wind-ruffled lake does not mirror that sprite as one solid square: the
    // solar reflection is broken across thousands of differently tilted wave
    // facets. Sample a small ring of the surrounding vanilla sky so only the
    // hard disc is removed; clouds, sky colour and weather remain untouched.
    vec2 ring = vec2(0.038 * viewHeight / max(viewWidth, 1.0), 0.038);
    vec2 diagonal = ring * 0.70710678;
    vec3 surroundingSky = vec3(0.0);
    surroundingSky += texture(colortex1, clamp(skyUV + vec2( ring.x, 0.0), vec2(0.001), vec2(0.999))).rgb;
    surroundingSky += texture(colortex1, clamp(skyUV + vec2(-ring.x, 0.0), vec2(0.001), vec2(0.999))).rgb;
    surroundingSky += texture(colortex1, clamp(skyUV + vec2(0.0,  ring.y), vec2(0.001), vec2(0.999))).rgb;
    surroundingSky += texture(colortex1, clamp(skyUV + vec2(0.0, -ring.y), vec2(0.001), vec2(0.999))).rgb;
    surroundingSky += texture(colortex1, clamp(skyUV + vec2( diagonal.x,  diagonal.y), vec2(0.001), vec2(0.999))).rgb;
    surroundingSky += texture(colortex1, clamp(skyUV + vec2(-diagonal.x,  diagonal.y), vec2(0.001), vec2(0.999))).rgb;
    surroundingSky += texture(colortex1, clamp(skyUV + vec2( diagonal.x, -diagonal.y), vec2(0.001), vec2(0.999))).rgb;
    surroundingSky += texture(colortex1, clamp(skyUV + vec2(-diagonal.x, -diagonal.y), vec2(0.001), vec2(0.999))).rgb;
    surroundingSky *= 0.125;

    return mix(directSky, surroundingSky, sunDiscMask);
}

vec3 vrwEnvironmentReflection(vec3 reflectionDirection) {
    vec3 direction = normalize(reflectionDirection);
    if (direction.z < -0.015) {
        vec2 skyUV = vrwViewToScreen(direction * 96.0);
        if (skyUV.x > 0.001 && skyUV.x < 0.999 &&
            skyUV.y > 0.001 && skyUV.y < 0.999) {
            return vrwSunlessSkySample(skyUV, direction);
        }
    }

    float elevation = dot(direction, normalize(upPosition));
    return mix(fogColor, skyColor, smoothstep(-0.10, 0.55, elevation));
}

vec3 vrwReflectionColor(vec3 surfaceView, vec3 reflectionDirection,
                        float roughness) {
    vec3 fallback = vrwEnvironmentReflection(reflectionDirection);
    vec2 hitUV;
    float confidence;

    if (!vrwTraceReflection(surfaceView, reflectionDirection, hitUV, confidence)) {
        return fallback;
    }

    vec2 pixel = vec2(1.0 / viewWidth, 1.0 / viewHeight);
    vec2 spread = pixel * mix(0.45, 1.45,
                              smoothstep(0.035, 0.14, roughness));
    vec3 reflected = texture(colortex1, hitUV).rgb * 0.50;
    reflected += texture(colortex1, hitUV + vec2(spread.x, 0.0)).rgb * 0.125;
    reflected += texture(colortex1, hitUV - vec2(spread.x, 0.0)).rgb * 0.125;
    reflected += texture(colortex1, hitUV + vec2(0.0, spread.y)).rgb * 0.125;
    reflected += texture(colortex1, hitUV - vec2(0.0, spread.y)).rgb * 0.125;
    return mix(fallback, reflected, confidence);
}

float vrwGlistenResponse(float sunAlignment) {
    sunAlignment = clamp(sunAlignment, 0.0, 1.0);

    // Three overlapping finite-width lobes retain the bright sun road and its
    // brilliant centres without the sub-pixel 900-power spikes that popped as
    // the camera crossed pixel boundaries.
    float road = pow(sunAlignment, 72.0) * 0.28;
    float shimmer = pow(sunAlignment, 140.0) * 0.82;
    float core = pow(sunAlignment, 360.0) * 0.50;
    return road + shimmer + core;
}

float vrwSampleGlisten(vec2 uv, vec3 sunDirection) {
    if (uv.x <= 0.001 || uv.x >= 0.999 ||
        uv.y <= 0.001 || uv.y >= 0.999) return -1.0;

    vec4 sampleData = texture(colortex2, uv);
    if (sampleData.a < 0.5 || sampleData.b < 0.0005) return -1.0;

    vec3 sampleSurfaceView = vrwViewRayPosition(uv, sampleData.b);
    vec3 sampleViewDirection = normalize(-sampleSurfaceView);
    vec3 sampleNormalView = vrwDecodeOctahedron(sampleData.rg);
    if (dot(sampleNormalView, sampleViewDirection) < 0.0) {
        sampleNormalView = -sampleNormalView;
    }

    vec3 sampleReflection = normalize(reflect(-sampleViewDirection,
                                               sampleNormalView));
    float sampleAlignment = max(dot(sampleReflection, sunDirection), 0.0);
    return vrwGlistenResponse(sampleAlignment);
}

void vrwAccumulateGlisten(
    vec2 uv,
    vec3 sunDirection,
    float sampleWeight,
    inout float responseSum,
    inout float weightSum
) {
    float response = vrwSampleGlisten(uv, sunDirection);
    if (response >= 0.0) {
        responseSum += response * sampleWeight;
        weightSum += sampleWeight;
    }
}

void main() {
    vec2 completedSceneUV = vScreenCoord;
#ifdef REFRACTION_ENABLED
    if (isEyeInWater == 1) {
        completedSceneUV = vrwUnderwaterRefractionUV(vScreenCoord);
    }
#endif
    vec4 completedScene = texture(colortex0, completedSceneUV);
    vec4 surfaceData = texture(colortex2, vScreenCoord);

    if (surfaceData.a < 0.5) {
        fragColor = completedScene;
        return;
    }

    bool isTopSurface = surfaceData.b >= 0.0;
    float waterLinearDepth = max(abs(surfaceData.b), 0.001);
    vec3 surfaceView = vrwViewRayPosition(vScreenCoord, waterLinearDepth);
    vec3 normalView = vrwDecodeOctahedron(surfaceData.rg);
    vec3 viewDirection = normalize(-surfaceView);
    if (dot(normalView, viewDirection) < 0.0) normalView = -normalView;

    vec2 refractedUV = vScreenCoord;
#ifdef REFRACTION_ENABLED
    vec3 flatWaterNormalView = normalize(mat3(gbufferModelView)
                                      * vec3(0.0, 1.0, 0.0));
    if (dot(flatWaterNormalView, viewDirection) < 0.0) {
        flatWaterNormalView = -flatWaterNormalView;
    }
    vec2 opticalSlope = isTopSurface
        ? normalView.xy - flatWaterNormalView.xy
        : vec2(0.0);
    float distanceAttenuation = 1.0 / (1.0 + waterLinearDepth * 0.018);
    // Strong enough to make the moving Gerstner slopes visibly bend the scene,
    // but still distance-damped and protected by the foreground-depth rejection
    // below so shorelines and nearby blocks do not smear across the surface.
    float refractionScale = 0.055 * REFRACTION_STRENGTH * distanceAttenuation;
    refractedUV = clamp(vScreenCoord + opticalSlope * refractionScale,
                        vec2(0.001), vec2(0.999));
#endif

    float refractedDepth = texture(depthtex1, refractedUV).r;
    vec3 backgroundView = vrwScreenToView(refractedUV, refractedDepth);
    if (refractedDepth < 0.99999 &&
        -backgroundView.z <= waterLinearDepth + 0.02) {
        refractedUV = vScreenCoord;
        refractedDepth = texture(depthtex1, refractedUV).r;
        backgroundView = vrwScreenToView(refractedUV, refractedDepth);
    }

    vec3 refractedColor = texture(colortex1, refractedUV).rgb;
    float waterThickness = refractedDepth >= 0.99999
        ? 64.0
        : clamp(length(backgroundView - surfaceView), 0.0, 64.0);

    // Clear aquamarine freshwater transmission plus a restrained scattering
    // colour driven by the captured scene's illumination. The captured vanilla
    // scene already contains Minecraft's lighting and fog, so neither is
    // applied a second time here and the tint cannot become night emission.
    float opticalDistance = waterThickness * WATER_OPACITY * 1.12;
    vec3 absorption = vec3(0.145, 0.032, 0.040);
    vec3 transmission = exp(-absorption * opticalDistance);
    float sceneIllumination = clamp(vrwLuminance(refractedColor) * 1.15
                              + vrwLuminance(skyColor) * 0.20, 0.0, 1.0);
    vec3 deepWaterColor = vec3(0.018, 0.095, 0.100)
                        * (0.88 * sceneIllumination);
    vec3 waterColor = refractedColor * transmission
                    + deepWaterColor * (vec3(1.0) - transmission);

#ifdef REFLECTION_ENABLED
    float waveRoughness = 0.0;
#ifdef WAVES_ENABLED
    waveRoughness = clamp(WAVE_STRENGTH / 0.360, 0.0, 1.0);
#endif
    float roughness = clamp(0.045 + waveRoughness * 0.035
                          + rainStrength * 0.040, 0.040, 0.125);
    vec3 reflectionDirection = normalize(reflect(-viewDirection, normalView));
    vec3 reflectedColor = vrwReflectionColor(surfaceView,
                                             reflectionDirection, roughness);

    float nDotV = clamp(dot(normalView, viewDirection), 0.0, 1.0);
    float fresnel = 0.0204 + 0.9796 * pow(1.0 - nDotV, 5.0);
    float reflectionWeight = clamp(fresnel * REFLECTION_STRENGTH, 0.0, 0.96);
    waterColor = mix(waterColor, reflectedColor, reflectionWeight);

    vec3 sunDirection = normalize(sunPosition);
    float sunElevation = dot(sunDirection, normalize(upPosition));
    float dayTime = mod(float(worldTime), 24000.0);
    float daylightMask = smoothstep(0.0, 700.0, dayTime)
                       * (1.0 - smoothstep(11600.0, 12800.0, dayTime));
    float skyBrightness = clamp(vrwLuminance(skyColor) * 1.35, 0.0, 1.0);
    vec3 daylightColor = mix(vec3(1.00, 0.72, 0.46),
                             vec3(1.00, 0.97, 0.88),
                             smoothstep(0.00, 0.32, sunElevation));
    // Evaluate the bright response from the world-anchored Gerstner normal
    // already stored by the water pass. A tiny Gaussian footprint integrates
    // neighbouring facet responses, acting like lightweight specular AA so
    // camera motion slides the glisten smoothly instead of making it pop.
    float filteredGlisten = 0.0;
    if (isTopSurface) {
        float resolvedSunAlignment = max(dot(reflectionDirection,
                                              sunDirection), 0.0);
        float responseSum = vrwGlistenResponse(resolvedSunAlignment) * 4.0;
        float responseWeight = 4.0;
        vec2 pixel = vec2(1.0 / viewWidth, 1.0 / viewHeight);

        vrwAccumulateGlisten(vScreenCoord + vec2( pixel.x, 0.0), sunDirection, 2.0, responseSum, responseWeight);
        vrwAccumulateGlisten(vScreenCoord + vec2(-pixel.x, 0.0), sunDirection, 2.0, responseSum, responseWeight);
        vrwAccumulateGlisten(vScreenCoord + vec2(0.0,  pixel.y), sunDirection, 2.0, responseSum, responseWeight);
        vrwAccumulateGlisten(vScreenCoord + vec2(0.0, -pixel.y), sunDirection, 2.0, responseSum, responseWeight);
        vrwAccumulateGlisten(vScreenCoord + vec2( pixel.x,  pixel.y), sunDirection, 1.0, responseSum, responseWeight);
        vrwAccumulateGlisten(vScreenCoord + vec2(-pixel.x,  pixel.y), sunDirection, 1.0, responseSum, responseWeight);
        vrwAccumulateGlisten(vScreenCoord + vec2( pixel.x, -pixel.y), sunDirection, 1.0, responseSum, responseWeight);
        vrwAccumulateGlisten(vScreenCoord + vec2(-pixel.x, -pixel.y), sunDirection, 1.0, responseSum, responseWeight);

        filteredGlisten = responseSum / max(responseWeight, 0.0001);
    }
    float glintAmount = clamp(filteredGlisten, 0.0, 0.88)
                        * daylightMask * skyBrightness
                        * smoothstep(-0.02, 0.12, sunElevation)
                        * (1.0 - rainStrength * 0.88)
                        * clamp(REFLECTION_STRENGTH, 0.0, 1.50);
    glintAmount = clamp(glintAmount, 0.0, 0.88);
    vec3 glistenColor = daylightColor
                      * mix(1.12, 1.30,
                            smoothstep(0.26, 0.88, filteredGlisten));
    waterColor = mix(waterColor, glistenColor, glintAmount);
#endif

    fragColor = vec4(waterColor, 1.0);
}
