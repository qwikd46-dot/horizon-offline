#version 330 core

in vec3 vaPosition;
in vec2 vaUV0;
uniform vec3 chunkOffset;
uniform mat4 modelViewMatrix;
uniform mat4 projectionMatrix;
uniform mat4 textureMatrix;

out vec2 vScreenCoord;

void main() {
    vec3 modelPosition = vaPosition + chunkOffset;
    gl_Position = projectionMatrix * modelViewMatrix * vec4(modelPosition, 1.0);
    vScreenCoord = (textureMatrix * vec4(vaUV0, 0.0, 1.0)).xy;
}
