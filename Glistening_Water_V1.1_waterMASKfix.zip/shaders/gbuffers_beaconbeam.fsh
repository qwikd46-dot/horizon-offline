#version 330 core
#define USE_TEXTURE
#define USE_FOG
#include "/lib/vanilla.fsh"
