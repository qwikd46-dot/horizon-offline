#version 330 core

#include "/lib/water_common.glsl"

in vec2 mc_Entity;
in vec4 at_midBlock;
in vec3 vaPosition;
in vec4 vaColor;
in vec2 vaUV0;
in ivec2 vaUV2;
in vec3 vaNormal;

uniform vec3 chunkOffset;
uniform mat4 modelViewMatrix;
uniform mat4 projectionMatrix;
uniform mat4 textureMatrix;
uniform mat3 normalMatrix;
uniform mat4 gbufferModelView;
uniform mat4 gbufferModelViewInverse;
uniform mat4 gbufferProjection;
uniform vec3 cameraPosition;
uniform float frameTimeCounter;

out vec2 vTexCoord;
out vec2 vLightCoord;
out vec4 vColor;
out vec3 vWorldPos;
out vec3 vViewPos;
out vec3 vBaseNormalWorld;
out float vWaveFade;
flat out int vIsWater;
flat out int vIsTopSurface;

const mat4 VRW_LIGHTMAP_MATRIX = mat4(
    vec4(0.00390625, 0.0, 0.0, 0.0),
    vec4(0.0, 0.00390625, 0.0, 0.0),
    vec4(0.0, 0.0, 0.00390625, 0.0),
    vec4(0.03125, 0.03125, 0.03125, 1.0)
);

void main() {
    vTexCoord = (textureMatrix * vec4(vaUV0, 0.0, 1.0)).xy;
    vLightCoord = (VRW_LIGHTMAP_MATRIX * vec4(vaUV2, 0.0, 1.0)).xy;
    vColor = vaColor;

    vec3 modelPosition = vaPosition + chunkOffset;
    vec3 viewPosition = (modelViewMatrix * vec4(modelPosition, 1.0)).xyz;
    vec3 playerPosition = (gbufferModelViewInverse * vec4(viewPosition, 1.0)).xyz;
    vec3 worldPosition = playerPosition + cameraPosition;
    vec3 normalWorld = normalize(mat3(gbufferModelViewInverse) * normalMatrix * vaNormal);

    vIsWater = (mc_Entity.y > 0.5 && abs(mc_Entity.x - 10001.0) < 0.5) ? 1 : 0;
    vIsTopSurface = normalWorld.y > 0.55 ? 1 : 0;
    vWaveFade = 1.0 - smoothstep(112.0, 224.0, length(playerPosition.xz));

    // Upper vertices on water side faces move with the horizontal surface. This
    // avoids a visible seam at shorelines while leaving every non-water vertex
    // on Minecraft's unmodified transform path.
    bool isUpperWaterVertex = at_midBlock.y < -1.0;
    if (vIsWater == 1 && (vIsTopSurface == 1 || isUpperWaterVertex)) {
        worldPosition += vrwGerstnerOffset(worldPosition.xz, frameTimeCounter) * vWaveFade;
        playerPosition = worldPosition - cameraPosition;
        viewPosition = (gbufferModelView * vec4(playerPosition, 1.0)).xyz;
        gl_Position = gbufferProjection * vec4(viewPosition, 1.0);
    } else {
        gl_Position = projectionMatrix * vec4(viewPosition, 1.0);
    }

    vWorldPos = worldPosition;
    vViewPos = viewPosition;
    vBaseNormalWorld = normalWorld;
}
