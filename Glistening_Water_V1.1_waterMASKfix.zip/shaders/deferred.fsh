#version 330 core

uniform sampler2D colortex0;
in vec2 vScreenCoord;
out vec4 fragColor;

void main() {
    // Preserve the completed vanilla opaque scene for water optics.
    /* RENDERTARGETS: 1 */
    fragColor = texture(colortex0, vScreenCoord);
}
