#version 330 core

uniform sampler2D colortex0;

in vec2 vScreenCoord;
out vec4 fragColor;

void main() {
    // Deliberate pass-through: no colour grading, bloom, custom exposure,
    // underwater relighting, fog replacement or post-processing.
    fragColor = texture(colortex0, vScreenCoord);
}
