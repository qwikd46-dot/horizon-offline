layout(triangles) in;
layout(triangle_strip, max_vertices = 3) out;

in vec2 vTexCoord[];
in vec2 vLightCoord[];
in vec4 vColor[];
in vec3 vViewPos[];

out vec2 gTexCoord;
out vec2 gLightCoord;
out vec4 gColor;
out vec3 gViewPos;
flat out vec2 gSpriteUVMin;
flat out vec2 gSpriteUVMax;

void main() {
    // Each indexed particle quad reaches this stage as two triangles. Either
    // triangle contains both UV extremes, so its three vertices recover the
    // complete sprite rectangle without relying on atlas tile dimensions.
    vec2 spriteUVMin = min(vTexCoord[0], min(vTexCoord[1], vTexCoord[2]));
    vec2 spriteUVMax = max(vTexCoord[0], max(vTexCoord[1], vTexCoord[2]));

    for (int vertex = 0; vertex < 3; ++vertex) {
        gl_Position = gl_in[vertex].gl_Position;
        gTexCoord = vTexCoord[vertex];
        gLightCoord = vLightCoord[vertex];
        gColor = vColor[vertex];
        gViewPos = vViewPos[vertex];
        gSpriteUVMin = spriteUVMin;
        gSpriteUVMax = spriteUVMax;
        EmitVertex();
    }
    EndPrimitive();
}
