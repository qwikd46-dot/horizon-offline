#ifndef VRW_SETTINGS_GLSL
#define VRW_SETTINGS_GLSL

// The shader settings screen intentionally exposes only these eight options.
#define REFRACTION_STRENGTH 1.50 // [0.00 0.25 0.50 0.75 1.00 1.25 1.50]
#define REFRACTION_ENABLED
#define REFLECTION_STRENGTH 1.00 // [0.00 0.25 0.50 0.75 1.00 1.25 1.50]
#define REFLECTION_ENABLED
#define WAVE_SPEED 0.80 // [0.00 0.25 0.40 0.60 0.80 1.00 1.25 1.50 1.75]
#define WAVES_ENABLED
#define WAVE_STRENGTH 0.220 // [0.000 0.050 0.100 0.140 0.180 0.220 0.280 0.360]
#define WATER_OPACITY 0.25 // [0.05 0.15 0.25 0.35 0.45 0.55 0.70 0.85]

#endif
