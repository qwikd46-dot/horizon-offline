uniform sampler2D gtexture;
uniform sampler2D lightmap;
uniform vec3 fogColor;
uniform float fogDensity;
uniform float fogStart;
uniform float fogEnd;
uniform int fogMode;
uniform int fogShape;

in vec2 gTexCoord;
in vec2 gLightCoord;
in vec4 gColor;
in vec3 gViewPos;
flat in vec2 gSpriteUVMin;
flat in vec2 gSpriteUVMax;

out vec4 fragColor;
/* RENDERTARGETS: 0 */

float vrwParticleFogVisibility(vec3 viewPosition) {
    float distanceToCamera = fogShape == 1
        ? max(length(viewPosition.xz), abs(viewPosition.y))
        : length(viewPosition);

    if (fogMode == 2048) {
        return clamp(exp(-fogDensity * distanceToCamera), 0.0, 1.0);
    }
    if (fogMode == 2049) {
        float densityDistance = fogDensity * distanceToCamera;
        return clamp(exp(-(densityDistance * densityDistance)), 0.0, 1.0);
    }
    return clamp((fogEnd - distanceToCamera) / max(fogEnd - fogStart, 0.0001),
                 0.0, 1.0);
}

void main() {
    vec2 sampleUV = gTexCoord;

    vec2 spriteSpan = gSpriteUVMax - gSpriteUVMin;
    if (spriteSpan.x > 0.000001 && spriteSpan.y > 0.000001) {
        vec2 localUV = (gTexCoord - gSpriteUVMin) / spriteSpan;

        // Apply the same footprint from every camera state. Previously the
        // sprite became small only after the camera entered water, so the exact
        // same suspended particle was still huge when seen through the surface.
        const float PARTICLE_SCALE = 0.40;
        vec2 remappedUV = (localUV - 0.5) / PARTICLE_SCALE + 0.5;
        if (any(lessThan(remappedUV, vec2(0.0))) ||
            any(greaterThan(remappedUV, vec2(1.0)))) {
            discard;
        }
        sampleUV = mix(gSpriteUVMin, gSpriteUVMax, remappedUV);
    }

    vec4 color = texture(gtexture, sampleUV)
               * texture(lightmap, gLightCoord)
               * gColor;
    color.rgb = mix(fogColor, color.rgb,
                    vrwParticleFogVisibility(gViewPos));
    fragColor = color;
}
