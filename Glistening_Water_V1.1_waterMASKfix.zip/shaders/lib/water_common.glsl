#ifndef VRW_WATER_COMMON_GLSL
#define VRW_WATER_COMMON_GLSL

#include "/lib/settings.glsl"

const float VRW_PI = 3.14159265358979323846;
const float VRW_TAU = 6.28318530717958647692;

vec2 vrwStableXZ(vec2 position) {
    return mod(position, 4096.0);
}

// Accumulates one physically travelling Gerstner component and its exact
// derivatives. No height-map noise, circular ripples or fake normal texture is
// involved: the wave motion and the optical normal come from the same field.
void vrwAddGerstner(
    vec2 position,
    vec2 direction,
    float wavelength,
    float amplitude,
    float speedMultiplier,
    float phaseOffset,
    float time,
    inout vec3 displacement,
    inout vec3 tangentX,
    inout vec3 tangentZ
) {
    direction = normalize(direction);
    float waveNumber = VRW_TAU / wavelength;
    float angularFrequency = sqrt(9.81 * waveNumber);
    float phase = waveNumber * dot(direction, position)
                - angularFrequency * WAVE_SPEED * speedMultiplier * time
                + phaseOffset;
    float sinePhase = sin(phase);
    float cosinePhase = cos(phase);
    // A lower horizontal ratio rounds the crests instead of pinching them into
    // the harsh, saw-toothed ridges produced by a steep Gerstner trochoid.
    float horizontalAmplitude = amplitude * 0.50;

    displacement += vec3(
        direction.x * horizontalAmplitude * cosinePhase,
        amplitude * sinePhase,
        direction.y * horizontalAmplitude * cosinePhase
    );

    float derivativeX = waveNumber * direction.x;
    float derivativeZ = waveNumber * direction.y;
    tangentX += vec3(
        -direction.x * horizontalAmplitude * sinePhase * derivativeX,
         amplitude * cosinePhase * derivativeX,
        -direction.y * horizontalAmplitude * sinePhase * derivativeX
    );
    tangentZ += vec3(
        -direction.x * horizontalAmplitude * sinePhase * derivativeZ,
         amplitude * cosinePhase * derivativeZ,
        -direction.y * horizontalAmplitude * sinePhase * derivativeZ
    );
}

void vrwAddWindWaves(
    vec2 position,
    float time,
    inout vec3 displacement,
    inout vec3 tangentX,
    inout vec3 tangentZ
) {
    // Six deliberately incommensurate wavelengths prevent an obvious tiled
    // beat. Energy is shifted toward longer lake-scale bands, while the short
    // components carry much less height; this preserves movement but makes the
    // surface broader, gentler and less stripe-like.
    vrwAddGerstner(position, vec2(1.000,  0.080), 23.70, WAVE_STRENGTH * 0.10, 0.58, 0.18, time, displacement, tangentX, tangentZ);
    vrwAddGerstner(position, vec2(0.985,  0.220), 14.90, WAVE_STRENGTH * 0.20, 0.71, 1.37, time, displacement, tangentX, tangentZ);
    vrwAddGerstner(position, vec2(0.950, -0.310),  9.35, WAVE_STRENGTH * 0.22, 0.84, 2.81, time, displacement, tangentX, tangentZ);
    vrwAddGerstner(position, vec2(0.900,  0.430),  6.15, WAVE_STRENGTH * 0.20, 0.99, 4.46, time, displacement, tangentX, tangentZ);
    vrwAddGerstner(position, vec2(0.995, -0.100),  3.92, WAVE_STRENGTH * 0.17, 1.14, 5.72, time, displacement, tangentX, tangentZ);
    vrwAddGerstner(position, vec2(0.860,  0.510),  2.63, WAVE_STRENGTH * 0.11, 1.31, 3.53, time, displacement, tangentX, tangentZ);
}

void vrwAddWindSurfaceDetail(
    vec2 position,
    float time,
    inout vec3 displacement,
    inout vec3 tangentX,
    inout vec3 tangentZ
) {
    // Very small capillary components break up reflection bands without adding
    // hard geometry. Their combined slope is substantially lower than v3.0.
    vrwAddGerstner(position, vec2(0.970,  0.260), 1.37, WAVE_STRENGTH * 0.025, 1.38, 0.91, time, displacement, tangentX, tangentZ);
    vrwAddGerstner(position, vec2(0.910, -0.420), 0.89, WAVE_STRENGTH * 0.014, 1.56, 4.08, time, displacement, tangentX, tangentZ);
    vrwAddGerstner(position, vec2(0.800,  0.600), 0.57, WAVE_STRENGTH * 0.006, 1.73, 2.17, time, displacement, tangentX, tangentZ);
}

vec3 vrwGerstnerOffset(vec2 worldXZ, float time) {
    vec3 displacement = vec3(0.0);
    vec3 tangentX = vec3(1.0, 0.0, 0.0);
    vec3 tangentZ = vec3(0.0, 0.0, 1.0);

#ifdef WAVES_ENABLED
    vrwAddWindWaves(vrwStableXZ(worldXZ), time, displacement, tangentX, tangentZ);
#endif

    return displacement;
}

vec3 vrwGerstnerNormal(vec2 worldXZ, float time) {
    vec3 displacement = vec3(0.0);
    vec3 tangentX = vec3(1.0, 0.0, 0.0);
    vec3 tangentZ = vec3(0.0, 0.0, 1.0);

#ifdef WAVES_ENABLED
    vec2 position = vrwStableXZ(worldXZ);
    vrwAddWindWaves(position, time, displacement, tangentX, tangentZ);
    vrwAddWindSurfaceDetail(position, time, displacement, tangentX, tangentZ);
#endif

    vec3 analyticNormal = normalize(cross(tangentZ, tangentX));
    return normalize(mix(vec3(0.0, 1.0, 0.0), analyticNormal, 0.92));
}

#endif
