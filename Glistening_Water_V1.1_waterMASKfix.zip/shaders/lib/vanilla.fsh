in vec2 vTexCoord;
in vec2 vLightCoord;
in vec4 vColor;
in vec3 vViewPos;

out vec4 fragColor;

#ifdef USE_TEXTURE
uniform sampler2D gtexture;
#endif
#ifdef USE_LIGHTMAP
uniform sampler2D lightmap;
#endif
#ifdef USE_ENTITY_COLOR
uniform vec4 entityColor;
#endif
#ifdef USE_FOG
uniform vec3 fogColor;
uniform float fogDensity;
uniform float fogStart;
uniform float fogEnd;
uniform int fogMode;
uniform int fogShape;
#endif
#ifdef USE_ALPHA_TEST
uniform float alphaTestRef;
#endif

float vanillaFogVisibility(vec3 viewPosition) {
#ifdef USE_FOG
    float distanceToCamera;
    if (fogShape == 1) {
        distanceToCamera = max(length(viewPosition.xz), abs(viewPosition.y));
    } else {
        distanceToCamera = length(viewPosition);
    }

    if (fogMode == 2048) {
        return clamp(exp(-fogDensity * distanceToCamera), 0.0, 1.0);
    }
    if (fogMode == 2049) {
        float d = fogDensity * distanceToCamera;
        return clamp(exp(-(d * d)), 0.0, 1.0);
    }
    return clamp((fogEnd - distanceToCamera) / max(fogEnd - fogStart, 0.0001), 0.0, 1.0);
#else
    return 1.0;
#endif
}

void main() {
    vec4 color = vColor;

#ifdef USE_TEXTURE
    color *= texture(gtexture, vTexCoord);
#endif
#ifdef USE_LIGHTMAP
    color *= texture(lightmap, vLightCoord);
#endif
#ifdef USE_ENTITY_COLOR
    color.rgb = mix(color.rgb, entityColor.rgb, entityColor.a);
#endif
#ifdef USE_ALPHA_TEST
    if (color.a < alphaTestRef) discard;
#endif
#ifdef USE_FOG
    color.rgb = mix(fogColor, color.rgb, vanillaFogVisibility(vViewPos));
#endif

    /* RENDERTARGETS: 0 */
    fragColor = color;
}
