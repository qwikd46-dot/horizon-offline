in vec3 vaPosition;
in vec4 vaColor;
in vec2 vaUV0;
in ivec2 vaUV2;

uniform vec3 chunkOffset;
uniform mat4 modelViewMatrix;
uniform mat4 projectionMatrix;
uniform mat4 textureMatrix;

const mat4 VRW_LIGHTMAP_MATRIX = mat4(
    vec4(0.00390625, 0.0, 0.0, 0.0),
    vec4(0.0, 0.00390625, 0.0, 0.0),
    vec4(0.0, 0.0, 0.00390625, 0.0),
    vec4(0.03125, 0.03125, 0.03125, 1.0)
);

out vec2 vTexCoord;
out vec2 vLightCoord;
out vec4 vColor;
out vec3 vViewPos;

void main() {
    vec3 modelPosition = vaPosition + chunkOffset;
    vec4 viewPosition = modelViewMatrix * vec4(modelPosition, 1.0);
    gl_Position = projectionMatrix * viewPosition;
    vTexCoord = (textureMatrix * vec4(vaUV0, 0.0, 1.0)).xy;
    vLightCoord = (VRW_LIGHTMAP_MATRIX * vec4(vaUV2, 0.0, 1.0)).xy;
    vColor = vaColor;
    vViewPos = viewPosition.xyz;
}
